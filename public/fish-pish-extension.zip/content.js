let h=null,y=null,b=null,n=null,f=null,m=null,v=!1;const q=600,H=1200,U=3e3,D=["google.com","youtube.com","wikipedia.org","github.com","stackoverflow.com","reddit.com","twitter.com","x.com","linkedin.com","facebook.com","microsoft.com","apple.com","amazon.com","netflix.com","paypal.com"];function $(e,t){if(t&&t.getAttribute("data-saferedirecturl")){const o=t.getAttribute("data-saferedirecturl");if(o)try{const a=new URL(o);if(a.searchParams.has("q"))return a.searchParams.get("q")||o}catch{}}try{const o=new URL(e);if(/google\.[a-z.]*$/.test(o.hostname)&&o.pathname==="/url"&&o.searchParams.has("q"))return o.searchParams.get("q")||e;if(o.hostname.includes("safelinks.protection.outlook.com")&&o.searchParams.has("url"))return o.searchParams.get("url")||e}catch{}return e}function O(){if(document.getElementById("fp-styles"))return;const e=document.createElement("style");e.id="fp-styles",e.textContent=`
    @keyframes fp-spin { to { transform: rotate(360deg); } }
    @keyframes fp-fade-in { from { opacity: 0; transform: translateY(-4px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes fp-fade-out { from { opacity: 1; transform: translateY(0); } to { opacity: 0; transform: translateY(-4px); } }
    @keyframes fp-pop-in { from { transform: scale(0.4); opacity: 0; } to { transform: scale(1); opacity: 1; } }

    #fp-popup-container {
      position: absolute;
      z-index: 2147483647;
      pointer-events: auto;
      font-family: 'Inter', system-ui, -apple-system, sans-serif;
      display: flex; flex-direction: column; align-items: flex-start;
    }
    #fp-popup-container * { box-sizing: border-box; }

    #fp-dot {
      width: 22px; height: 22px;
      border-radius: 50%;
      background: rgba(120,120,140,0.85);
      backdrop-filter: blur(8px);
      display: flex; align-items: center; justify-content: center;
      cursor: pointer;
      animation: fp-pop-in 0.25s cubic-bezier(0.175,0.885,0.32,1.275) both;
      transition: background 0.3s, box-shadow 0.3s;
      box-shadow: 0 2px 8px rgba(0,0,0,0.2);
    }
    #fp-dot.safe   { background: linear-gradient(135deg,#11998e,#38ef7d); box-shadow: 0 0 0 3px rgba(56,239,125,0.2); }
    #fp-dot.warn   { background: linear-gradient(135deg,#f7971e,#ffd200); box-shadow: 0 0 0 3px rgba(255,210,0,0.2); }
    #fp-dot.danger { background: linear-gradient(135deg,#c0392b,#e74c3c); box-shadow: 0 0 0 3px rgba(231,76,60,0.2); }

    #fp-spinner {
      width: 11px; height: 11px;
      border: 2px solid rgba(255,255,255,0.3); border-top-color: #fff;
      border-radius: 50%; animation: fp-spin 0.7s linear infinite;
    }

    #fp-tooltip {
      margin-top: 6px;
      background: rgba(20,20,35,0.92); backdrop-filter: blur(8px);
      padding: 4px 10px; border-radius: 6px;
      color: #fff; font-size: 10.5px; font-weight: 600; white-space: nowrap;
      box-shadow: 0 3px 10px rgba(0,0,0,0.3);
      animation: fp-fade-in 0.25s ease both;
    }

    #fp-detail-panel {
      margin-top: 8px;
      width: 290px;
      background: rgba(15,15,25,0.96);
      backdrop-filter: blur(16px);
      border-radius: 14px;
      padding: 16px;
      padding-bottom: 35px; /* Reserve space for the expand/collapse button */
      border-left: 5px solid transparent;
      box-shadow: 0 12px 40px rgba(0,0,0,0.45);
      animation: fp-fade-in 0.35s ease both;
      color: #e8e8f0;
      position: relative;
    }
    #fp-detail-panel.border-safe   { border-left-color: #38ef7d; }
    #fp-detail-panel.border-warn   { border-left-color: #ffd200; }
    #fp-detail-panel.border-danger { border-left-color: #e74c3c; }

    #fp-close-btn {
      position: absolute; top: 12px; right: 12px;
      width: 22px; height: 22px;
      display: flex; align-items: center; justify-content: center;
      cursor: pointer; color: #6a6a8a; font-size: 16px; font-weight: 600;
      border-radius: 50%; background: rgba(255,255,255,0.06);
      transition: all 0.2s; z-index: 10;
    }
    #fp-close-btn:hover { color: #fff; background: rgba(255,255,255,0.12); transform: scale(1.1); }

    .fp-header { display: flex; align-items: center; gap: 8px; margin-bottom: 12px; padding-right: 30px; }
    .fp-brand { font-size: 13px; font-weight: 700; color: #fff; }
    .fp-risk-badge { margin-left: auto; font-size: 10.5px; font-weight: 700; padding: 2px 8px; border-radius: 20px; }
    .fp-risk-badge.safe   { background: rgba(56,239,125,0.15); color: #38ef7d; }
    .fp-risk-badge.danger { background: rgba(231,76,60,0.18);  color: #e74c3c; }
    .fp-risk-badge.warn   { background: rgba(255,210,0,0.15);  color: #ffd200; }

    .fp-info-block { border-radius: 10px; padding: 10px 12px; margin-bottom: 12px; font-size: 11px; line-height: 1.5; }
    .fp-info-label { font-size: 9.5px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.8px; margin-bottom: 4px; display: block; }

    .fp-signals { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; }
    .fp-signal-item { background: rgba(255,255,255,0.04); border-radius: 8px; padding: 7px 8px; font-size: 10.5px; color: #9999b8; }
    .fp-sig-label { font-weight: 600; color: #c8c8e0; display: block; margin-bottom: 2px; }

    /* Expanded UI Styles */
    #fp-expand-toggle {
      position: absolute; bottom: 12px; left: 18px;
      font-size: 9px; font-weight: 800; text-transform: uppercase;
      letter-spacing: 0.6px; color: #a07cff; cursor: pointer;
      opacity: 0.7; transition: all 0.2s;
      display: flex; align-items: center; gap: 3px;
      user-select: none;
    }
    #fp-expand-toggle:hover { opacity: 1; color: #fff; }

    .fp-advanced-section {
      margin-top: 15px; padding-top: 15px;
      border-top: 1px solid rgba(255,255,255,0.1);
      display: none; flex-direction: column; gap: 12px;
      animation: fp-fade-in 0.3s ease;
    }
    .fp-action-btns { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
    .fp-btn {
      padding: 8px; border-radius: 8px; font-size: 10px; font-weight: 700;
      text-align: center; cursor: pointer; transition: 0.2s;
      display: flex; align-items: center; justify-content: center; gap: 4px;
    }
    .fp-btn-report { background: rgba(255,255,255,0.06); color: #fff; border: 1px solid rgba(255,255,255,0.1); }
    .fp-btn-report:hover { background: rgba(255,255,255,0.12); }
    .fp-btn-kill { background: rgba(231,76,60,0.1); color: #e74c3c; border: 1px solid rgba(231,76,60,0.2); }
    .fp-btn-kill:hover { background: rgba(231,76,60,0.2); }
    .fp-btn-kill.active { background: #e74c3c; color: #fff; }

    .fp-chat-box {
      background: rgba(0,0,0,0.2); border-radius: 10px; padding: 8px;
      display: flex; flex-direction: column; gap: 6px;
    }
    .fp-chat-history {
      max-height: 80px; overflow-y: auto; font-size: 10px; color: #9999b8;
      display: flex; flex-direction: column; gap: 4px; padding-right: 4px;
    }
    .fp-chat-history::-webkit-scrollbar { width: 3px; }
    .fp-chat-history::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.1); border-radius: 3px; }
    
    .fp-msg { padding: 4px 8px; border-radius: 6px; line-height: 1.4; }
    .fp-msg-user { align-self: flex-end; background: rgba(160,124,255,0.15); color: #d4c4ff; }
    .fp-msg-ai { align-self: flex-start; background: rgba(255,255,255,0.05); color: #e8e8f0; }

    .fp-chat-input-wrap { display: flex; gap: 6px; }
    .fp-chat-input {
      flex: 1; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1);
      border-radius: 6px; padding: 4px 8px; color: #fff; font-size: 10px; outline: none;
    }
    .fp-chat-send {
      background: #a07cff; color: #fff; border: none; border-radius: 6px;
      width: 24px; height: 24px; display: flex; align-items: center; justify-content: center;
      cursor: pointer; font-weight: bold;
    }
    @keyframes fp-pop-out { from { transform: scale(1); opacity: 1; } to { transform: scale(0); opacity: 0; } }
    .fp-dot-hide { animation: fp-pop-out 0.2s ease forwards; pointer-events: none; }
  `,document.head.appendChild(e)}document.addEventListener("mouseover",e=>{const t=e.target.closest("a");!t||!t.href||!t.href.startsWith("http")||(s(h),h=setTimeout(()=>{console.log("Fish-Pish: Hover detected on link:",t.href),Y(t)},q))});document.addEventListener("mouseout",e=>{e.target.closest("a")&&(s(h),s(y),n&&!n.dataset.panelOpen&&B())});function Y(e){const t=$(e.href,e);if(console.log("Fish-Pish: Unwrapped URL:",t),f===t&&n)return;P(),O(),f=t;const o=e.getBoundingClientRect(),a=document.createElement("div");a.id="fp-popup-container",a.style.top=`${o.bottom+window.scrollY+6}px`,a.style.left=`${o.left+window.scrollX}px`;const p=document.createElement("div");p.id="fp-dot",p.innerHTML='<div id="fp-spinner"></div>',a.appendChild(p),document.body.appendChild(a),n=a,a.addEventListener("mouseenter",()=>{s(b),a.dataset.hovered="true"}),a.addEventListener("mouseleave",()=>{delete a.dataset.hovered,B()}),p.addEventListener("click",()=>{if(!v)return;document.getElementById("fp-detail-panel")?_():j()});const i=(e.innerText||e.getAttribute("aria-label")||e.title||"").trim();N(t,i),F()}async function N(e,t){try{const o=await chrome.runtime.sendMessage({type:"ANALYZE_URL",url:e,linkText:t,fast:!0});if(o.success){m=o.data;const a=new URL(e).hostname.toLowerCase(),p=D.some(i=>a.includes(i));(o.data.color!=="green"||p)&&M(o.data.color)}}catch{}try{const o=await chrome.runtime.sendMessage({type:"ANALYZE_URL",url:e,linkText:t,fast:!1});if(o.success){m=o.data,v=!0,M(o.data.color);const a=document.getElementById("fp-tooltip");a&&(a.textContent="Analysis Ready · Click Dot")}}catch{}}function M(e){const t=document.getElementById("fp-dot");if(!t)return;const o=document.getElementById("fp-spinner");o&&o.remove(),t.classList.remove("safe","warn","danger"),t.classList.add(e==="red"?"danger":e==="yellow"?"warn":"safe")}function j(){var S,T,C,A,I,z,R;if(!n||!m)return;n.dataset.panelOpen="true";const e=document.getElementById("fp-tooltip");e&&e.remove();const t=m,o=document.getElementById("fp-dot");o&&o.classList.add("fp-dot-hide");const a=t.color==="red"?"#e74c3c":t.color==="yellow"?"#ffd200":"#38ef7d",p=t.color==="red"?"border-danger":t.color==="yellow"?"border-warn":"border-safe",i=document.createElement("div");i.id="fp-detail-panel",i.classList.add(p);const x=(S=t.details)==null?void 0:S.llm,E=(x==null?void 0:x.reasoning)||"Analyzing psychological intent...";i.innerHTML=`
    <div id="fp-close-btn">&times;</div>
    <div class="fp-header">
      <span class="fp-brand">Fish-Pish Intelligence</span>
      <span class="fp-risk-badge ${t.color==="red"?"danger":t.color==="yellow"?"warn":"safe"}">${t.phishing_probability}% Risk</span>
    </div>
    <div class="fp-bar-track"><div class="fp-bar-fill" style="width:${t.phishing_probability}%;background:${a}"></div></div>
    
    <div class="fp-info-block" style="background:rgba(160,124,255,0.08); border:1px solid rgba(160,124,255,0.2)">
      <span class="fp-info-label" style="color:#a07cff">🤖 AI VERDICT</span>
      <span style="font-style:italic; font-size:11.5px">"${E}"</span>
    </div>

    <div class="fp-signals">
      <div class="fp-signal-item">
        <span class="fp-sig-label">Safe Browsing</span>
        ${(T=t.signals)!=null&&T.safe_browsing_skipped?"⚠️ Unchecked":(C=t.signals)!=null&&C.safe_browsing?"❌ Flagged":"✅ Safe"}
      </div>
      <div class="fp-signal-item">
        <span class="fp-sig-label">SSL Layer</span>
        ${(A=t.signals)!=null&&A.ssl_secure?"🔒 Secure":"⚠️ Insecure"}
      </div>
    </div>

    <!-- Advanced Toggle -->
    <div id="fp-expand-toggle">Expand ▾</div>

    <!-- Advanced Section -->
    <div class="fp-advanced-section">
      <div class="fp-action-btns">
        <div class="fp-btn fp-btn-report" id="fp-btn-report">🚩 Report</div>
        <div class="fp-btn fp-btn-kill" id="fp-btn-kill">🚫 Kill JS</div>
      </div>

      <div class="fp-chat-box">
        <div class="fp-chat-history" id="fp-chat-history">
          <div class="fp-msg fp-msg-ai">How can I help you regarding this link?</div>
        </div>
        <div class="fp-chat-input-wrap">
          <input type="text" class="fp-chat-input" id="fp-chat-input" placeholder="Ask AI about this link...">
          <button class="fp-chat-send" id="fp-chat-send">→</button>
        </div>
      </div>
    </div>
  `,(I=i.querySelector("#fp-close-btn"))==null||I.addEventListener("click",r=>{r.stopPropagation(),_()});const g=i.querySelector("#fp-expand-toggle");g==null||g.addEventListener("click",()=>{const r=i.querySelector(".fp-advanced-section");r.style.display==="flex"?(r.style.display="none",i.style.width="290px",g.innerHTML="Expand ▾"):(r.style.display="flex",i.style.width="320px",g.innerHTML="Collapse ▴")}),(z=i.querySelector("#fp-btn-report"))==null||z.addEventListener("click",()=>{chrome.runtime.sendMessage({type:"REPORT_LINK",url:f})}),(R=i.querySelector("#fp-btn-kill"))==null||R.addEventListener("click",function(){const c=this.classList.contains("active")?"allow":"block";chrome.runtime.sendMessage({type:"BLOCK_JS",url:f,action:c},l=>{l!=null&&l.success&&(c==="block"?(this.classList.add("active"),this.textContent="🔒 JS Locked"):(this.classList.remove("active"),this.textContent="🚫 Kill JS"))})});const u=i.querySelector("#fp-chat-input"),k=i.querySelector("#fp-chat-send"),d=i.querySelector("#fp-chat-history"),L=()=>{const r=u.value.trim();if(!r)return;const c=document.createElement("div");c.className="fp-msg fp-msg-user",c.textContent=r,d.appendChild(c),u.value="",d.scrollTop=d.scrollHeight,chrome.runtime.sendMessage({type:"CHAT_MESSAGE",text:r,context:{url:f,probability:t.phishing_probability,reasoning:E}},l=>{const w=document.createElement("div");w.className="fp-msg fp-msg-ai",w.textContent=l!=null&&l.success?l.response:"Sorry, I couldn't reach the backend.",d.appendChild(w),d.scrollTop=d.scrollHeight})};k==null||k.addEventListener("click",L),u==null||u.addEventListener("keypress",r=>{r.key==="Enter"&&L()}),n.appendChild(i),s(b)}function _(){const e=document.getElementById("fp-detail-panel");e&&(e.style.animation="fp-fade-out 0.2s ease forwards",setTimeout(()=>{e.remove(),n&&delete n.dataset.panelOpen;const t=document.getElementById("fp-dot");t&&t.classList.remove("fp-dot-hide")},200))}function B(){s(b),!(n!=null&&n.dataset.panelOpen)&&(b=setTimeout(()=>{n&&!n.dataset.hovered&&(n.style.animation="fp-fade-out 0.2s ease forwards",setTimeout(P,200))},U))}function P(){s(h),s(y),s(b),n&&n.remove(),n=null,f=null,m=null,v=!1}function F(){s(y),y=setTimeout(()=>{if(!n||n.querySelector("#fp-tooltip"))return;const e=document.createElement("div");e.id="fp-tooltip",e.style.textAlign="center",e.innerHTML=v?"Report Ready<br><span style='font-size:9px;opacity:0.8'>Click for more details</span>":"Analysing...",n.appendChild(e)},H)}function s(e){e&&clearTimeout(e)}
